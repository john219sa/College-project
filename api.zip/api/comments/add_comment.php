<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

require_once '../config/database.php';

$data     = json_decode(file_get_contents("php://input"), true);
$child_id = $data['child_id'] ?? null;
$user_id  = $data['user_id']  ?? null;
$comment  = $data['comment']  ?? null;

if (!$child_id || !$user_id || !$comment) {
    echo json_encode(['status' => false, 'message' => 'child_id و user_id و comment مطلوبين']);
    exit;
}

$stmt = $conn->prepare(
    "INSERT INTO child_comments (child_id, user_id, comment) VALUES (?, ?, ?)"
);
$stmt->bind_param("iis", $child_id, $user_id, $comment);

if ($stmt->execute()) {
    echo json_encode(['status' => true, 'message' => 'تم إضافة التعليق بنجاح', 'id' => $stmt->insert_id]);
} else {
    echo json_encode(['status' => false, 'message' => 'فشل الإضافة: ' . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
