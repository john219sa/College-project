<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
require_once "../config/database.php";

// ── مجلدات الرفع ───────────────────────────────────────────────
$uploadBase = __DIR__ . "/../../uploads/curriculum/";
$dirs = ['pdfs', 'images', 'videos'];
foreach ($dirs as $d) {
    if (!is_dir($uploadBase . $d)) {
        mkdir($uploadBase . $d, 0777, true);
    }
}

// ── البيانات النصية ────────────────────────────────────────────
$specialistIdsRaw = $_POST['specialist_ids'] ?? '[]';
$specialistIds    = json_decode($specialistIdsRaw, true);
$comment          = trim($_POST['comment']   ?? '');
$exercise         = trim($_POST['exercise']  ?? '');
$treatment        = trim($_POST['treatment'] ?? '');

if (empty($specialistIds) || !is_array($specialistIds)) {
    echo json_encode(["status" => false, "message" => "specialist_ids مطلوب"]);
    exit;
}

// ── رفع PDF ─────────────────────────────────────────────────────
$pdfPaths = [];
if (!empty($_FILES['pdfs'])) {
    foreach ($_FILES['pdfs']['tmp_name'] as $i => $tmp) {
        if ($_FILES['pdfs']['error'][$i] === UPLOAD_ERR_OK) {
            $name = time() . '_' . basename($_FILES['pdfs']['name'][$i]);
            $dest = $uploadBase . 'pdfs/' . $name;
            if (move_uploaded_file($tmp, $dest)) {
                $pdfPaths[] = 'uploads/curriculum/pdfs/' . $name;
            }
        }
    }
}

// ── رفع صور ─────────────────────────────────────────────────────
$imagePaths = [];
if (!empty($_FILES['images'])) {
    foreach ($_FILES['images']['tmp_name'] as $i => $tmp) {
        if ($_FILES['images']['error'][$i] === UPLOAD_ERR_OK) {
            $ext  = pathinfo($_FILES['images']['name'][$i], PATHINFO_EXTENSION);
            $name = time() . '_' . $i . '.' . $ext;
            $dest = $uploadBase . 'images/' . $name;
            if (move_uploaded_file($tmp, $dest)) {
                $imagePaths[] = 'uploads/curriculum/images/' . $name;
            }
        }
    }
}

// ── رفع فيديو ───────────────────────────────────────────────────
$videoPath = null;
if (!empty($_FILES['video']) && $_FILES['video']['error'] === UPLOAD_ERR_OK) {
    $ext  = pathinfo($_FILES['video']['name'], PATHINFO_EXTENSION);
    $name = time() . '_video.' . $ext;
    $dest = $uploadBase . 'videos/' . $name;
    if (move_uploaded_file($_FILES['video']['tmp_name'], $dest)) {
        $videoPath = 'uploads/curriculum/videos/' . $name;
    }
}

// ── الحفظ في الداتا بيز ──────────────────────────────────────────
// جدول curriculum_uploads — شوف SQL في الأسفل
$comment_esc   = mysqli_real_escape_string($conn, $comment);
$exercise_esc  = mysqli_real_escape_string($conn, $exercise);
$treatment_esc = mysqli_real_escape_string($conn, $treatment);
$pdfs_json     = mysqli_real_escape_string($conn, json_encode($pdfPaths));
$images_json   = mysqli_real_escape_string($conn, json_encode($imagePaths));
$video_val     = $videoPath ? "'" . mysqli_real_escape_string($conn, $videoPath) . "'" : "NULL";

mysqli_begin_transaction($conn);
try {
    // حفظ واحد لكل أخصائي محدد
    foreach ($specialistIds as $spId) {
        $spId = intval($spId);
        $sql  = "INSERT INTO curriculum_uploads
                 (specialist_id, comment, exercise, treatment, pdf_paths, image_paths, video_path)
                 VALUES
                 ($spId, '$comment_esc', '$exercise_esc', '$treatment_esc',
                  '$pdfs_json', '$images_json', $video_val)";
        mysqli_query($conn, $sql);
    }
    mysqli_commit($conn);
    echo json_encode([
        "status"  => true,
        "message" => "تم رفع المنهج بنجاح لـ " . count($specialistIds) . " أخصائي"
    ]);
} catch (Exception $e) {
    mysqli_rollback($conn);
    echo json_encode(["status" => false, "message" => "خطأ: " . $e->getMessage()]);
}

/*
════════════════════════════════════════════════════════
SQL الجدول المطلوب — شغّله في MySQL Workbench
════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS curriculum_uploads (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    specialist_id INT NOT NULL,
    comment       TEXT,
    exercise      TEXT,
    treatment     TEXT,
    pdf_paths     JSON,
    image_paths   JSON,
    video_path    VARCHAR(500),
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (specialist_id) REFERENCES users(id) ON DELETE CASCADE
);

*/
?>
