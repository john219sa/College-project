<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

require_once '../config/database.php';

$child_id = $_GET['child_id'] ?? null;

if (!$child_id) {
    echo json_encode(['status' => false, 'message' => 'child_id مطلوب']);
    exit;
}

$stmt = $conn->prepare("
    SELECT cc.id, cc.comment, cc.created_at,
           u.id AS user_id, u.full_name, u.role
    FROM child_comments cc
    JOIN users u ON cc.user_id = u.id
    WHERE cc.child_id = ?
    ORDER BY cc.created_at DESC
");
$stmt->bind_param("i", $child_id);
$stmt->execute();
$result = $stmt->get_result();

$comments = [];
while ($row = $result->fetch_assoc()) {
    $comments[] = $row;
}

echo json_encode(['status' => true, 'comments' => $comments]);

$stmt->close();
$conn->close();
?>
