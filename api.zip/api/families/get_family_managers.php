<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
require_once "../config/database.php";

$family_id = isset($_GET['family_id']) ? intval($_GET['family_id']) : 0;

if ($family_id <= 0) {
    echo json_encode(["status" => false, "message" => "family_id required"]);
    exit;
}

$sql = "SELECT id, full_name, role, phone, email
        FROM users
        WHERE family_id = $family_id 
        AND role IN ('family_manager', 'assistant')
        AND is_active = 1
        ORDER BY role ASC";

$result = mysqli_query($conn, $sql);
$list = [];
while ($row = mysqli_fetch_assoc($result)) {
    $list[] = $row;
}

echo json_encode(["status" => true, "data" => $list]);
?>