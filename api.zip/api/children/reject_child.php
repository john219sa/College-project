<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
require_once "../config/database.php";

$data = json_decode(file_get_contents("php://input"), true);
$waiting_id = isset($data['waiting_id']) ? intval($data['waiting_id']) : 0;

if ($waiting_id <= 0) {
    echo json_encode(["status" => false, "message" => "waiting_id مطلوب"]);
    exit;
}

$sql = "UPDATE waiting_list SET status = 'rejected' WHERE id = $waiting_id AND status = 'pending'";
if (mysqli_query($conn, $sql) && mysqli_affected_rows($conn) > 0) {
    echo json_encode(["status" => true, "message" => "تم رفض الحالة"]);
} else {
    echo json_encode(["status" => false, "message" => "لم يتم التحديث — الحالة غير موجودة أو معالجة مسبقاً"]);
}
?>