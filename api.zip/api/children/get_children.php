<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

require_once "../config/database.php";

// ✅ بياخد family_id من GET مش POST
$family_id = isset($_GET['family_id']) ? intval($_GET['family_id']) : 0;

if ($family_id > 0) {
    $sql = "SELECT id, name, age, diagnosis FROM children WHERE family_id = $family_id ORDER BY id DESC";
} else {
    // لو مفيش family_id يرجع كل الأطفال (للأدمن)
    $sql = "SELECT id, name, age, diagnosis FROM children ORDER BY id DESC";
}

$result = mysqli_query($conn, $sql);
$children = [];
while ($row = mysqli_fetch_assoc($result)) {
    $children[] = $row;
}

echo json_encode(["status" => true, "data" => $children]);