<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
include("../config/database.php");

$family_id = isset($_GET['family_id']) ? intval($_GET['family_id']) : 0;

if ($family_id <= 0) {
    echo json_encode(["status" => false, "message" => "family_id مطلوب"]);
    exit;
}

// جيب الجلسات اللي الأخصائي بتاعها في نفس الأسرة
$sql = "
    SELECT DISTINCT
        s.id,
        s.session_date,
        s.session_time,
        s.location,
        s.session_type,
        s.status,
        s.notes,
        s.created_at,
        u.full_name      AS specialist_name,
        u.specialist_type
    FROM sessions s
    JOIN users u ON s.specialist_id = u.id
    WHERE u.family_id = $family_id AND u.is_active = 1
    ORDER BY s.session_date DESC, s.session_time ASC
";

$result   = mysqli_query($conn, $sql);
$sessions = [];

while ($row = mysqli_fetch_assoc($result)) {
    $sid = $row['id'];

    // الأطفال لكل جلسة
    $ch_result = mysqli_query($conn, "
        SELECT c.id, c.name, c.age, c.diagnosis
        FROM session_children sc
        JOIN children c ON sc.child_id = c.id
        WHERE sc.session_id = $sid
    ");
    $children = [];
    while ($ch = mysqli_fetch_assoc($ch_result)) {
        $children[] = $ch;
    }
    $row['children'] = $children;
    $sessions[]      = $row;
}

$total   = count($sessions);
$done    = count(array_filter($sessions, fn($s) => $s['status'] === 'done'));
$pending = count(array_filter($sessions, fn($s) => $s['status'] === 'pending'));

echo json_encode([
    "status" => true,
    "stats"  => [
        "total"   => $total,
        "done"    => $done,
        "pending" => $pending,
    ],
    "data"   => $sessions,
]);
?>