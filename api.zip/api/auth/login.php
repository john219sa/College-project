<?php

header("Content-Type: application/json");

include("../config/database.php");

$data = json_decode(file_get_contents("php://input"));

if (
    empty($data->email) ||
    empty($data->password)
) {

    echo json_encode([
        "status" => false,
        "message" => "Email and password required"
    ]);

    exit;
}

$email = trim($data->email);
$password = trim($data->password);

$sql = "

SELECT

    users.id,
    users.full_name,
    users.email,
    users.phone,
    users.password,
    users.role,
    users.family_id,
    users.child_id,
    users.assistant_for,
    users.specialist_type,
    users.is_active,

    families.name AS family_name

FROM users

LEFT JOIN families
ON users.family_id = families.id

WHERE users.email = ?

LIMIT 1

";

$stmt = $conn->prepare($sql);

$stmt->bind_param("s", $email);

$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows > 0) {

    $user = $result->fetch_assoc();

    // ================= CHECK ACTIVE =================

    if ((int)$user['is_active'] != 1) {

        echo json_encode([
            "status" => false,
            "message" => "Account disabled"
        ]);

        exit;
    }

    // ================= PASSWORD CHECK =================

    if ($password == $user['password']) {

        echo json_encode([

            "status" => true,

            "message" => "Login success",

            "data" => [

                "id" => (int)$user['id'],

                "full_name" => $user['full_name'],

                "email" => $user['email'],

                "phone" => $user['phone'],

                "role" => $user['role'],

                "family_id" => $user['family_id']
                    ? (int)$user['family_id']
                    : 0,

                "family_name" => $user['family_name']
                    ? $user['family_name']
                    : "",

                "child_id" => $user['child_id']
                    ? (int)$user['child_id']
                    : 0,

                "assistant_for" => $user['assistant_for']
                    ? (int)$user['assistant_for']
                    : 0,

                "specialist_type" => $user['specialist_type']
                    ? $user['specialist_type']
                    : ""

            ]
        ]);
    }

    // ================= WRONG PASSWORD =================

    else {

        echo json_encode([
            "status" => false,
            "message" => "Wrong password"
        ]);
    }
}

 // ================= USER NOT FOUND =================

// ================= USER NOT FOUND في users =================
else {

    // ابحث في waiting_list
    $wSql  = "SELECT id, name, status FROM waiting_list WHERE email = ? LIMIT 1";
    $wStmt = $conn->prepare($wSql);
    $wStmt->bind_param("s", $email);
    $wStmt->execute();
    $wResult = $wStmt->get_result();

    if ($wResult->num_rows > 0) {
        $wRow = $wResult->fetch_assoc();

        if ($wRow['status'] === 'pending') {
            echo json_encode([
                "status"       => false,
                "waiting"      => true,
                "message"      => "طلبك قيد المراجعة، سيتم إخطارك عند القبول",
                "waiting_name" => $wRow['name']
            ]);
        } elseif ($wRow['status'] === 'rejected') {
            echo json_encode([
                "status"  => false,
                "waiting" => false,
                "message" => "عذراً، تم رفض طلبك"
            ]);
        }
    } else {
        echo json_encode([
            "status"  => false,
            "waiting" => false,
            "message" => "User not found"
        ]);
    }

    $wStmt->close();
}

$stmt->close();

$conn->close();

?>