<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
require_once "../config/database.php";

$data = json_decode(file_get_contents("php://input"), true);

$specialist_id = intval($data['specialist_id'] ?? 0);
$child_ids     = $data['child_ids']    ?? [];
$session_date  = mysqli_real_escape_string($conn, $data['session_date']  ?? '');
$session_time  = mysqli_real_escape_string($conn, $data['session_time']  ?? '');
$location      = mysqli_real_escape_string($conn, $data['location']      ?? '');
$session_type  = mysqli_real_escape_string($conn, $data['session_type']  ?? '');
$notes         = mysqli_real_escape_string($conn, $data['notes']         ?? '');
$created_by    = intval($data['created_by'] ?? 1);

if ($specialist_id <= 0 || empty($child_ids) || empty($session_date) || empty($session_time)) {
    echo json_encode(["status" => false, "message" => "البيانات ناقصة"]);
    exit;
}

mysqli_begin_transaction($conn);
try {
    // ✅ INSERT واحدة فقط في sessions
    mysqli_query($conn,
        "INSERT INTO sessions 
         (specialist_id, session_date, session_time, location, session_type, notes, created_by)
         VALUES 
         ($specialist_id, '$session_date', '$session_time', '$location', '$session_type', '$notes', $created_by)"
    );
    $session_id = mysqli_insert_id($conn);

    // ✅ INSERT كل الأطفال في session_children تحت نفس الجلسة
    foreach ($child_ids as $child_id) {
        $child_id = intval($child_id);
        if ($child_id <= 0) continue;
        mysqli_query($conn,
            "INSERT IGNORE INTO session_children (session_id, child_id)
             VALUES ($session_id, $child_id)"
        );
    }

    mysqli_commit($conn);
    echo json_encode([
        "status"     => true,
        "message"    => "تم إضافة الجلسة بنجاح مع " . count($child_ids) . " طفل",
        "session_id" => $session_id,
    ]);

} catch (Exception $e) {
    mysqli_rollback($conn);
    echo json_encode(["status" => false, "message" => $e->getMessage()]);
}
?>