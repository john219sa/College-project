<?php

header("Content-Type: application/json");

$conn = new mysqli(
    "localhost",
    "root",
    "",
    "autism_care_system"
);

if ($conn->connect_error) {

    echo json_encode([
        "status" => false,
        "message" => "Database connection failed"
    ]);

    exit;
}

$childrenQuery = "
SELECT COUNT(*) AS total_children
FROM children
";

$specialistsQuery = "
SELECT COUNT(*) AS total_specialists
FROM users
WHERE role = 'specialist'
";

$familiesQuery = "

SELECT

    f.id AS family_id,

    f.name AS family_name,

    IFNULL(u.full_name, 'لا يوجد') AS manager_name,

    (
        SELECT COUNT(*)
        FROM children c
        WHERE c.family_id = f.id
    ) AS children_count,

    (
        SELECT COUNT(*)
        FROM users s
        WHERE s.family_id = f.id
        AND s.role = 'specialist'
    ) AS specialists_count

FROM families f

LEFT JOIN users u
ON u.family_id = f.id
AND u.role = 'family_manager'

";

$childrenResult = $conn->query($childrenQuery);

$specialistsResult = $conn->query($specialistsQuery);

$familiesResult = $conn->query($familiesQuery);

$childrenCount = $childrenResult->fetch_assoc()['total_children'];

$specialistsCount = $specialistsResult->fetch_assoc()['total_specialists'];

$families = [];

while ($row = $familiesResult->fetch_assoc()) {

    $families[] = $row;
}

echo json_encode([

    "status" => true,

    "children_count" => (int)$childrenCount,

    "specialists_count" => (int)$specialistsCount,

    "families" => $families

]);

?>