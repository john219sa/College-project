<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

require_once '../config/database.php';

$data = json_decode(file_get_contents("php://input"), true);

$child_id = $data['child_id'] ?? null;
$age      = $data['age']      ?? null;
$diagnosis= $data['diagnosis']?? null;
$name     = $data['name']     ?? null;

if (!$child_id) {
    echo json_encode(['status' => false, 'message' => 'child_id مطلوب']);
    exit;
}

$fields = [];
$params = [];
$types  = '';

if ($name !== null) {
    $fields[] = "name = ?";
    $params[]  = $name;
    $types    .= 's';
}
if ($age !== null) {
    $fields[] = "age = ?";
    $params[]  = (int)$age;
    $types    .= 'i';
}
if ($diagnosis !== null) {
    $fields[] = "diagnosis = ?";
    $params[]  = $diagnosis;
    $types    .= 's';
}

if (empty($fields)) {
    echo json_encode(['status' => false, 'message' => 'لا توجد بيانات للتعديل']);
    exit;
}

$sql = "UPDATE children SET " . implode(', ', $fields) . " WHERE id = ?";
$params[] = (int)$child_id;
$types   .= 'i';

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);

if ($stmt->execute()) {
    echo json_encode(['status' => true, 'message' => 'تم تعديل بيانات الطفل بنجاح']);
} else {
    echo json_encode(['status' => false, 'message' => 'فشل التعديل: ' . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
