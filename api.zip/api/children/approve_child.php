<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
require_once "../config/database.php";

$data = json_decode(file_get_contents("php://input"), true);
$waiting_id     = isset($data['waiting_id'])     ? intval($data['waiting_id'])  : 0;
$family_id      = isset($data['family_id'])      ? intval($data['family_id'])   : 0;
$diagnosis      = isset($data['diagnosis'])      ? trim($data['diagnosis'])     : '';
$specialist_ids = isset($data['specialist_ids']) ? $data['specialist_ids']      : [];

if ($waiting_id <= 0 || $family_id <= 0) {
    echo json_encode(["status" => false, "message" => "waiting_id و family_id مطلوبان"]);
    exit;
}

$row = mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT * FROM waiting_list WHERE id = $waiting_id AND status = 'pending' LIMIT 1"
));

if (!$row) {
    echo json_encode(["status" => false, "message" => "الحالة غير موجودة أو تمت معالجتها مسبقاً"]);
    exit;
}

mysqli_begin_transaction($conn);
try {
    $name_esc  = mysqli_real_escape_string($conn, $row['name']);
    $diag_esc  = mysqli_real_escape_string($conn, $diagnosis ?: $row['service_type']);
    $email_esc = mysqli_real_escape_string($conn, $row['email']);
    $pass_esc  = mysqli_real_escape_string($conn, $row['password']);
    $phone_esc = mysqli_real_escape_string($conn, $row['phone']);

    // 1. أضف لجدول children
    mysqli_query($conn,
        "INSERT INTO children (family_id, name, age, diagnosis)
         VALUES ($family_id, '$name_esc', {$row['age']}, '$diag_esc')"
    );
    $child_id = mysqli_insert_id($conn);

    // 2. أنشئ حساب للطفل
    mysqli_query($conn,
        "INSERT INTO users (full_name, email, phone, password, role, child_id, family_id)
         VALUES ('$name_esc', '$email_esc', '$phone_esc', '$pass_esc', 'child', $child_id, $family_id)"
    );

    // 3. أضف الأخصائيين
    foreach ($specialist_ids as $sp_id) {
        $sp_id = intval($sp_id);
        if ($sp_id > 0) {
            mysqli_query($conn,
                "INSERT IGNORE INTO specialist_children (specialist_id, child_id)
                 VALUES ($sp_id, $child_id)"
            );
        }
    }

    // 4. حدّث حالة الانتظار
    mysqli_query($conn,
        "UPDATE waiting_list SET status = 'approved', family_id = $family_id
         WHERE id = $waiting_id"
    );

    mysqli_commit($conn);
    echo json_encode([
        "status"   => true,
        "message"  => "تم قبول الطفل وإنشاء حسابه بنجاح",
        "child_id" => $child_id
    ]);

} catch (Exception $e) {
    mysqli_rollback($conn);
    echo json_encode(["status" => false, "message" => "خطأ: " . $e->getMessage()]);
}
?>