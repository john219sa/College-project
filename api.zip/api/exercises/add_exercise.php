<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

require_once '../config/database.php';

$data         = json_decode(file_get_contents("php://input"), true);
$child_id     = (int)($data['child_id']    ?? 0);
$created_by   = (int)($data['created_by']  ?? 0);
$title        = $data['title']             ?? null;
$instructions = $data['instructions']      ?? null;

if (!$child_id || !$created_by || !$title) {
    echo json_encode(['status' => false, 'message' => 'child_id و created_by و title مطلوبين']);
    exit;
}

$stmt = $conn->prepare(
    "INSERT INTO child_exercises (child_id, title, instructions, created_by)
     VALUES (?, ?, ?, ?)"
);
$stmt->bind_param("issi", $child_id, $title, $instructions, $created_by);

if ($stmt->execute()) {
    echo json_encode(['status' => true, 'message' => 'تم إضافة التمرين بنجاح', 'id' => $stmt->insert_id]);
} else {
    echo json_encode(['status' => false, 'message' => 'فشل الإضافة: ' . $stmt->error]);
}

$stmt->close();
$conn->close();
?>