<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

require_once '../config/database.php';

$child_id = $_GET['child_id'] ?? null;

if (!$child_id) {
    echo json_encode(['status' => false, 'message' => 'child_id مطلوب']);
    exit;
}

$stmt = $conn->prepare("
    SELECT ct.id, ct.title, ct.description, ct.created_at,
           u.full_name AS created_by_name
    FROM child_treatments ct
    LEFT JOIN users u ON ct.created_by = u.id
    WHERE ct.child_id = ?
    ORDER BY ct.created_at DESC
");
$stmt->bind_param("i", $child_id);
$stmt->execute();
$result = $stmt->get_result();

$treatments = [];
while ($row = $result->fetch_assoc()) {
    $treatments[] = $row;
}

echo json_encode(['status' => true, 'treatments' => $treatments]);

$stmt->close();
$conn->close();
?>
