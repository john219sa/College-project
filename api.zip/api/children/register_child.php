<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
require_once "../config/database.php";

$data = json_decode(file_get_contents("php://input"), true);

$name         = isset($data['name'])         ? trim($data['name'])         : '';
$age          = isset($data['age'])          ? intval($data['age'])        : 0;
$phone        = isset($data['phone'])        ? trim($data['phone'])        : '';
$service_type = isset($data['service_type']) ? trim($data['service_type']) : '';
$email        = isset($data['email'])        ? trim($data['email'])        : '';
$password     = isset($data['password'])     ? trim($data['password'])     : '';
$created_by   = isset($data['created_by'])   ? intval($data['created_by']) : null;
$family_id    = isset($data['family_id'])    ? intval($data['family_id'])  : null;

// Validation
if (empty($name) || empty($phone) || empty($email) || empty($password)) {
    echo json_encode(["status" => false, "message" => "الاسم والهاتف والإيميل وكلمة المرور مطلوبة"]);
    exit;
}

// التحقق من عدم تكرار الإيميل في waiting_list أو users
$check = mysqli_query($conn,
    "SELECT id FROM waiting_list WHERE email = '" . mysqli_real_escape_string($conn, $email) . "' LIMIT 1"
);
if (mysqli_num_rows($check) > 0) {
    echo json_encode(["status" => false, "message" => "هذا الإيميل مسجل بالفعل في قائمة الانتظار"]);
    exit;
}

$check2 = mysqli_query($conn,
    "SELECT id FROM users WHERE email = '" . mysqli_real_escape_string($conn, $email) . "' LIMIT 1"
);
if (mysqli_num_rows($check2) > 0) {
    echo json_encode(["status" => false, "message" => "هذا الإيميل مسجل بالفعل"]);
    exit;
}

// الإدخال في waiting_list
$name_esc     = mysqli_real_escape_string($conn, $name);
$phone_esc    = mysqli_real_escape_string($conn, $phone);
$service_esc  = mysqli_real_escape_string($conn, $service_type);
$email_esc    = mysqli_real_escape_string($conn, $email);
$pass_esc     = mysqli_real_escape_string($conn, $password); // استخدم password_hash في الإنتاج

$family_val   = $family_id ? $family_id : "NULL";
$creator_val  = $created_by ? $created_by : "NULL";

$sql = "INSERT INTO waiting_list 
        (name, age, phone, service_type, email, password, family_id, created_by)
        VALUES 
        ('$name_esc', $age, '$phone_esc', '$service_esc', '$email_esc', '$pass_esc', $family_val, $creator_val)";

if (mysqli_query($conn, $sql)) {
    echo json_encode([
        "status" => true,
        "message" => "تم تسجيل الطفل بنجاح وهو الآن في قائمة الانتظار",
        "waiting_id" => mysqli_insert_id($conn)
    ]);
} else {
    echo json_encode(["status" => false, "message" => "خطأ في قاعدة البيانات: " . mysqli_error($conn)]);
}
?>