<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
require_once "../config/database.php";

$family_id = isset($_GET['family_id']) ? intval($_GET['family_id']) : 0;
$all       = isset($_GET['all']) && $_GET['all'] == '1';

// لو all=1 أو مفيش family_id → رجّع كل الأخصائيين
if ($all || $family_id <= 0) {
    $sql = "SELECT id, full_name, specialist_type, family_id
            FROM users
            WHERE role = 'specialist' AND is_active = 1
            ORDER BY specialist_type, full_name";
} else {
    $sql = "SELECT id, full_name, specialist_type, family_id
            FROM users
            WHERE role = 'specialist' AND is_active = 1 AND family_id = $family_id
            ORDER BY specialist_type, full_name";
}

$result = mysqli_query($conn, $sql);
$list   = [];
while ($row = mysqli_fetch_assoc($result)) {
    $list[] = $row;
}

echo json_encode(["status" => true, "data" => $list]);
?>