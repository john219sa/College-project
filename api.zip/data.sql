CREATE DATABASE autism_care_system
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE autism_care_system;

-- ===============================
-- FAMILIES
-- ===============================
CREATE TABLE families (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(150) NOT NULL UNIQUE,
    description TEXT,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO families (name, description) VALUES
('أسرة الحالات الشديدة',  'الحالات الشديدة'),
('أسرة الحالات المتوسطة', 'الحالات المتوسطة'),
('أسرة الحالات الضعيفة',  'الحالات الضعيفة');

-- ===============================
-- CHILDREN
-- ===============================
CREATE TABLE children (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    family_id   INT NOT NULL,
    name        VARCHAR(150) NOT NULL,
    age         INT,
    diagnosis   TEXT,
    avatar_path VARCHAR(300) NULL,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE
);

-- ===============================
-- USERS
-- ===============================
CREATE TABLE users (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    full_name        VARCHAR(150) NOT NULL,
    email            VARCHAR(150) UNIQUE NOT NULL,
    phone            VARCHAR(20),
    password         VARCHAR(255) NOT NULL,
    role             ENUM('admin','family_manager','assistant','specialist','child') NOT NULL,
    specialist_type  ENUM(
                         'speech',
                         'psychologist',
                         'behavior',
                         'special_education',
                         'occupational_therapy'
                     ) NULL,
    family_id        INT NULL,
    child_id         INT NULL UNIQUE,
    assistant_for    INT NULL,
    avatar_path      VARCHAR(300) NULL,
    is_active        TINYINT(1) DEFAULT 1,
    created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (family_id)     REFERENCES families(id) ON DELETE SET NULL,
    FOREIGN KEY (child_id)      REFERENCES children(id) ON DELETE CASCADE,
    FOREIGN KEY (assistant_for) REFERENCES users(id)   ON DELETE SET NULL
);

-- ===============================
-- SPECIALIST CHILDREN
-- ===============================
CREATE TABLE specialist_children (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    specialist_id INT NOT NULL,
    child_id      INT NOT NULL,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (specialist_id) REFERENCES users(id)    ON DELETE CASCADE,
    FOREIGN KEY (child_id)      REFERENCES children(id) ON DELETE CASCADE,
    UNIQUE(specialist_id, child_id)
);

-- ===============================
-- CHILD REPORTS
-- ===============================
CREATE TABLE child_reports (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    child_id       INT NOT NULL,
    report_text    TEXT,
    progress_level VARCHAR(100),
    created_by     INT,
    created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (child_id)   REFERENCES children(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id)    ON DELETE SET NULL
);

-- ===============================
-- CHILD COMMENTS
-- ===============================
CREATE TABLE child_comments (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    child_id   INT NOT NULL,
    user_id    INT NOT NULL,
    comment    TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (child_id) REFERENCES children(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id)  REFERENCES users(id)    ON DELETE CASCADE
);

-- ===============================
-- CHILD EXERCISES
-- ===============================
CREATE TABLE child_exercises (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    child_id     INT NOT NULL,
    title        VARCHAR(255),
    instructions TEXT,
    created_by   INT,
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (child_id)   REFERENCES children(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id)    ON DELETE SET NULL
);

-- ===============================
-- CHILD TREATMENTS
-- ===============================
CREATE TABLE child_treatments (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    child_id    INT NOT NULL,
    title       VARCHAR(255),
    description TEXT,
    created_by  INT,
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (child_id)   REFERENCES children(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id)    ON DELETE SET NULL
);

-- ===============================
-- WAITING LIST
-- ===============================
CREATE TABLE waiting_list (
    id                   INT AUTO_INCREMENT PRIMARY KEY,
    name                 VARCHAR(150) NOT NULL,
    age                  INT,
    phone                VARCHAR(20),
    service_type         VARCHAR(100),
    email                VARCHAR(150),
    password             VARCHAR(255),
    status               ENUM('pending','approved','rejected') DEFAULT 'pending',
    assigned_specialists JSON NULL,
    assigned_family_id   INT NULL,
    family_id            INT NULL,
    created_by           INT NULL,
    created_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (assigned_family_id) REFERENCES families(id) ON DELETE SET NULL,
    FOREIGN KEY (family_id)          REFERENCES families(id) ON DELETE SET NULL,
    FOREIGN KEY (created_by)         REFERENCES users(id)    ON DELETE SET NULL
);

-- ===============================
-- CHILD SCANS
-- ===============================
CREATE TABLE child_scans (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    child_id   INT NOT NULL,
    file_name  VARCHAR(255),
    file_path  VARCHAR(255),
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (child_id)   REFERENCES children(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id)    ON DELETE SET NULL
);

-- ===============================
-- CHILD TESTS
-- ===============================
CREATE TABLE child_tests (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    child_id   INT NOT NULL,
    file_name  VARCHAR(255),
    file_path  VARCHAR(255),
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (child_id)   REFERENCES children(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id)    ON DELETE SET NULL
);

-- ===============================
-- CURRICULUM UPLOADS
-- ===============================
CREATE TABLE curriculum_uploads (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    specialist_id INT NOT NULL,
    comment       TEXT,
    exercise      TEXT,
    treatment     TEXT,
    pdf_paths     JSON,
    image_paths   JSON,
    video_path    VARCHAR(500),
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (specialist_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ================================================================
-- DATA
-- ================================================================

-- ===============================
-- ADMIN  (id = 1)
-- ===============================
INSERT INTO users (full_name, email, phone, password, role) VALUES
('جون صفوت فكري', 'john219saf@gmail.com', '01000000001', '163425', 'admin');

-- ===============================
-- FAMILY MANAGERS  (ids 2-4)
-- ===============================
INSERT INTO users (full_name, email, phone, password, role, family_id) VALUES
('بسنت مجدي',  'basant.magdy@autism.com',  '01011111101', 'manager123', 'family_manager', 1),
('فاطمة محمد', 'fatma.mohamed@autism.com', '01011111102', 'manager123', 'family_manager', 2),
('مينا رضا',   'mina.reda@autism.com',     '01011111103', 'manager123', 'family_manager', 3);

-- ===============================
-- ASSISTANTS  (ids 5-7)
-- ===============================
INSERT INTO users (full_name, email, phone, password, role, family_id, assistant_for) VALUES
('لميس عادل', 'lamis.adel@autism.com',  '01022222201', 'assist123', 'assistant', 1, 2),
('يوسف سامي', 'yousef.samy@autism.com', '01022222202', 'assist123', 'assistant', 2, 3),
('دينا حسام',  'dina.hossam@autism.com', '01022222203', 'assist123', 'assistant', 3, 4);

-- ===============================
-- SPECIALISTS
-- أسرة شديدة  → 6 أخصائيين  (ids 8-13)
-- أسرة متوسطة → 3 أخصائيين  (ids 14-16)
-- أسرة ضعيفة  → 2 أخصائيين  (ids 17-18)
-- ===============================
INSERT INTO users (full_name, email, phone, password, role, specialist_type, family_id) VALUES
-- شديدة
('مي عوض محمد',       'mai.awad@autism.com',     '01033333301', 'spec123', 'specialist', 'speech',               1),
('جاسر محمد',          'jaser.mohamed@autism.com', '01033333302', 'spec123', 'specialist', 'psychologist',         1),
('عمر محمد',           'omar.mohamed@autism.com',  '01033333303', 'spec123', 'specialist', 'behavior',             1),
('نور أحمد سالم',      'nour.ahmed@autism.com',    '01033333304', 'spec123', 'specialist', 'speech',               1),
('ريم خالد عمر',       'reem.khaled@autism.com',   '01033333305', 'spec123', 'specialist', 'special_education',    1),
('كريم يوسف علي',      'karim.yousef@autism.com',  '01033333306', 'spec123', 'specialist', 'occupational_therapy', 1),
-- متوسطة
('سارة وليد حسن',      'sara.walid@autism.com',    '01033333307', 'spec123', 'specialist', 'speech',               2),
('هنا طارق محمود',     'hana.tarek@autism.com',    '01033333308', 'spec123', 'specialist', 'psychologist',         2),
('أحمد ماهر رضا',      'ahmed.maher@autism.com',   '01033333309', 'spec123', 'specialist', 'behavior',             2),
-- ضعيفة
('رنا سامح إبراهيم',   'rana.sameh@autism.com',    '01033333310', 'spec123', 'specialist', 'speech',               3),
('مصطفى علاء الدين',   'mostafa.alaa@autism.com',  '01033333311', 'spec123', 'specialist', 'occupational_therapy', 3);

-- ===============================
-- CHILDREN
-- أسرة شديدة  → 15 طفل  (ids 1-15)
-- أسرة متوسطة → 21 طفل  (ids 16-36)
-- أسرة ضعيفة  → 25 طفل  (ids 37-61)
-- ===============================

-- أسرة شديدة (family_id = 1) — 15 طفل
INSERT INTO children (family_id, name, age, diagnosis) VALUES
(1, 'يوسف أحمد سعيد',      6,  'توحد شديد'),
(1, 'ملك محمد علي',         7,  'توحد مع تأخر لغوي'),
(1, 'زياد خالد حسن',        5,  'فرط حركة ونقص انتباه'),
(1, 'سلمى وليد عمر',        8,  'توحد شديد'),
(1, 'كريم سامح رضا',        9,  'صعوبات تعلم حادة'),
(1, 'لارا طارق محمود',      6,  'توحد مع اضطراب حسي'),
(1, 'آدم حسام إبراهيم',     7,  'تأخر نمائي شامل'),
(1, 'مريم عمر يوسف',        5,  'توحد شديد'),
(1, 'عمر أشرف ناصر',        8,  'اضطراب طيف توحد'),
(1, 'نور سامي فتحي',        6,  'فرط حركة مع توحد'),
(1, 'حنين علاء الدين',      7,  'توحد مع صعوبات تواصل'),
(1, 'باسل مينا رضا',        9,  'تأخر لغوي حاد'),
(1, 'تاليا وائل حنا',       5,  'توحد شديد'),
(1, 'مازن رامي سلامة',      8,  'اضطراب سلوكي حاد'),
(1, 'روان ياسر مصطفى',      6,  'توحد مع ضعف انتباه');

-- أسرة متوسطة (family_id = 2) — 21 طفل
INSERT INTO children (family_id, name, age, diagnosis) VALUES
(2, 'أميرة سيد أحمد',       7,  'توحد متوسط'),
(2, 'محمد عادل نور',         8,  'تأخر لغوي متوسط'),
(2, 'ليلى حسن مكاوي',       6,  'فرط حركة'),
(2, 'عبدالله وليد جمال',    9,  'صعوبات تعلم'),
(2, 'دانا رامي إبراهيم',    5,  'توحد متوسط'),
(2, 'جود طارق السيد',        7,  'تأخر نمائي'),
(2, 'كريس ماجد فهمي',       8,  'ضعف انتباه'),
(2, 'لوجين سامي خليل',      6,  'توحد متوسط'),
(2, 'ريان أحمد شحاتة',      7,  'اضطراب طيف خفيف'),
(2, 'علي عصام زيدان',        9,  'صعوبات تواصل'),
(2, 'سنا خالد منصور',        5,  'تأخر لغوي'),
(2, 'يارا وائل سعد',         8,  'فرط حركة خفيف'),
(2, 'زين مصطفى قاسم',       6,  'توحد متوسط'),
(2, 'مايا رأفت جرجس',       7,  'صعوبات تعلم'),
(2, 'فارس حسام عطية',       9,  'ضعف انتباه'),
(2, 'رنا نادر فؤاد',         5,  'توحد خفيف'),
(2, 'أنس إيهاب درويش',      8,  'تأخر نمائي'),
(2, 'كنزي علاء رشدي',       6,  'اضطراب سلوكي'),
(2, 'تيم سامح جاد',          7,  'صعوبات تعلم'),
(2, 'مي أحمد الشافعي',      9,  'توحد متوسط'),
(2, 'لين حاتم مجدي',         5,  'تأخر لغوي متوسط');

-- أسرة ضعيفة (family_id = 3) — 25 طفل
INSERT INTO children (family_id, name, age, diagnosis) VALUES
(3, 'ياسمين فريد حلمي',     8,  'توحد خفيف'),
(3, 'عمر إسلام راغب',       7,  'تأخر لغوي بسيط'),
(3, 'هنا سامي الخولي',      6,  'ضعف انتباه بسيط'),
(3, 'ادم محمد حجازي',       9,  'صعوبات تعلم بسيطة'),
(3, 'نادية طه عبدالعزيز',   5,  'توحد خفيف'),
(3, 'مروان كريم صالح',      8,  'فرط حركة بسيط'),
(3, 'إيلا وسام عطالله',     7,  'تأخر نمائي بسيط'),
(3, 'حمزة رفيق عبده',       6,  'ضعف انتباه'),
(3, 'لوسي مجدي بسطا',       9,  'صعوبات تعلم'),
(3, 'سيف الدين علي رمضان',  5,  'توحد خفيف جداً'),
(3, 'أسيل حمدي النجار',     8,  'تأخر لغوي'),
(3, 'نزار وليد عوض',        7,  'فرط حركة بسيط'),
(3, 'رهف أشرف شعبان',       6,  'صعوبات تعلم'),
(3, 'بيسان سعيد الجوهري',   9,  'ضعف انتباه بسيط'),
(3, 'كايروس ميلاد وهبة',    5,  'توحد خفيف'),
(3, 'سجى محمود حسانين',     8,  'تأخر نمائي'),
(3, 'عمار إيهاب الرافعي',   7,  'صعوبات تواصل بسيطة'),
(3, 'إيمان صلاح السيد',     6,  'توحد خفيف جداً'),
(3, 'ليوناردو هاني فلتس',   9,  'فرط حركة'),
(3, 'نيللي رامي الشرقاوي',  5,  'ضعف انتباه'),
(3, 'حسين طارق الزيات',     8,  'تأخر لغوي بسيط'),
(3, 'مريم سامر حبيب',       7,  'توحد خفيف'),
(3, 'جورج مينا عزيز',       6,  'صعوبات تعلم بسيطة'),
(3, 'منار أحمد البسيوني',   9,  'تأخر نمائي بسيط'),
(3, 'كريستيان نادي ميخائيل',5,  'ضعف انتباه بسيط');

-- ===============================
-- CHILD ACCOUNTS
-- ===============================
INSERT INTO users (full_name, email, phone, password, role, child_id)
SELECT name,
       CONCAT('child', id, '@autism.com'),
       '01099999999',
       '123456',
       'child',
       id
FROM children;

-- ================================================================
-- SPECIALIST ↔ CHILDREN RELATIONS
-- ================================================================

-- ── أسرة شديدة (children ids 1-15, specialists ids 8-13) ──────
-- مي عوض (8) — تخاطب — كل الأطفال
INSERT INTO specialist_children (specialist_id, child_id) VALUES
(8,1),(8,2),(8,3),(8,4),(8,5),(8,6),(8,7),(8,8),(8,9),(8,10),(8,11),(8,12),(8,13),(8,14),(8,15);

-- جاسر (9) — نفسي — نصف الأطفال
INSERT INTO specialist_children (specialist_id, child_id) VALUES
(9,1),(9,2),(9,3),(9,4),(9,5),(9,6),(9,7),(9,8);

-- عمر (10) — سلوك — نصف الأطفال
INSERT INTO specialist_children (specialist_id, child_id) VALUES
(10,8),(10,9),(10,10),(10,11),(10,12),(10,13),(10,14),(10,15);

-- نور (11) — تخاطب — مجموعة مختارة
INSERT INTO specialist_children (specialist_id, child_id) VALUES
(11,3),(11,4),(11,5),(11,9),(11,10),(11,11),(11,14),(11,15);

-- ريم (12) — تربية خاصة — مجموعة مختارة
INSERT INTO specialist_children (specialist_id, child_id) VALUES
(12,1),(12,6),(12,7),(12,12),(12,13);

-- كريم (13) — علاج وظيفي — مجموعة مختارة
INSERT INTO specialist_children (specialist_id, child_id) VALUES
(13,2),(13,5),(13,8),(13,11),(13,14);

-- ── أسرة متوسطة (children ids 16-36, specialists ids 14-16) ──
-- سارة (14) — تخاطب — كل الأطفال
INSERT INTO specialist_children (specialist_id, child_id) VALUES
(14,16),(14,17),(14,18),(14,19),(14,20),(14,21),(14,22),(14,23),(14,24),(14,25),
(14,26),(14,27),(14,28),(14,29),(14,30),(14,31),(14,32),(14,33),(14,34),(14,35),(14,36);

-- هنا (15) — نفسي — نصف الأطفال
INSERT INTO specialist_children (specialist_id, child_id) VALUES
(15,16),(15,17),(15,18),(15,19),(15,20),(15,21),(15,22),(15,23),(15,24),(15,25),(15,26);

-- أحمد ماهر (16) — سلوك — نصف الأطفال
INSERT INTO specialist_children (specialist_id, child_id) VALUES
(16,26),(16,27),(16,28),(16,29),(16,30),(16,31),(16,32),(16,33),(16,34),(16,35),(16,36);

-- ── أسرة ضعيفة (children ids 37-61, specialists ids 17-18) ───
-- رنا (17) — تخاطب — كل الأطفال
INSERT INTO specialist_children (specialist_id, child_id) VALUES
(17,37),(17,38),(17,39),(17,40),(17,41),(17,42),(17,43),(17,44),(17,45),(17,46),(17,47),(17,48),
(17,49),(17,50),(17,51),(17,52),(17,53),(17,54),(17,55),(17,56),(17,57),(17,58),(17,59),(17,60),(17,61);

-- مصطفى (18) — علاج وظيفي — نصف الأطفال
INSERT INTO specialist_children (specialist_id, child_id) VALUES
(18,37),(18,38),(18,39),(18,40),(18,41),(18,42),(18,43),(18,44),(18,45),(18,46),(18,47),(18,48),(18,49);

-- ================================================================
-- VERIFY
-- ================================================================
SELECT 'families'         AS tbl, COUNT(*) AS cnt FROM families
UNION ALL
SELECT 'children',         COUNT(*) FROM children
UNION ALL
SELECT 'users',            COUNT(*) FROM users
UNION ALL
SELECT 'specialist_children', COUNT(*) FROM specialist_children;

-- ===============================
-- SESSIONS (جلسات)
-- ===============================
CREATE TABLE sessions (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    specialist_id INT NOT NULL,
    child_id      INT NOT NULL,
    session_date  DATE NOT NULL,
    session_time  TIME NOT NULL,
    room          VARCHAR(100),
    type          VARCHAR(100),
    status        ENUM('pending','done') DEFAULT 'pending',
    notes         TEXT,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (specialist_id) REFERENCES users(id)    ON DELETE CASCADE,
    FOREIGN KEY (child_id)      REFERENCES children(id) ON DELETE CASCADE
);
-- ================================================================
-- إصلاح جدول sessions
-- شغّل هذا الكود في MySQL Workbench بعد الداتا بيز الحالية
-- ================================================================

USE autism_care_system;

-- ── 1. امسح جدول sessions القديم ─────────────────────────────
DROP TABLE IF EXISTS sessions;

-- ── 2. أنشئ جدول sessions الصح ────────────────────────────────
CREATE TABLE sessions (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    specialist_id INT NOT NULL,
    session_date  DATE         NOT NULL,
    session_time  TIME         NOT NULL,
    location      VARCHAR(100) NOT NULL,
    session_type  VARCHAR(100) NOT NULL,
    status        ENUM('pending','done','cancelled') DEFAULT 'pending',
    notes         TEXT         DEFAULT NULL,
    created_by    INT          NOT NULL,
    created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (specialist_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by)    REFERENCES users(id) ON DELETE CASCADE
);

-- ── 3. أنشئ جدول session_children ─────────────────────────────
CREATE TABLE IF NOT EXISTS session_children (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    session_id INT NOT NULL,
    child_id   INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES sessions(id)  ON DELETE CASCADE,
    FOREIGN KEY (child_id)   REFERENCES children(id)  ON DELETE CASCADE,
    UNIQUE(session_id, child_id)
);

-- ── تحقق ─────────────────────────────────────────────────────
SHOW TABLES;
DESCRIBE sessions;
DESCRIBE session_children;

USE autism_care_system;

-- مسؤولو الأسر
UPDATE users SET email = 'basant.magdy@gmail.com'  WHERE id = 2;
UPDATE users SET email = 'fatma.mohamed@gmail.com' WHERE id = 3;
UPDATE users SET email = 'mina.reda@gmail.com'     WHERE id = 4;

-- المساعدون
UPDATE users SET email = 'lamis.adel@gmail.com'  WHERE id = 5;
UPDATE users SET email = 'yousef.samy@gmail.com' WHERE id = 6;
UPDATE users SET email = 'dina.hossam@gmail.com' WHERE id = 7;

-- الأخصائيون
UPDATE users SET email = 'mai.awad@gmail.com'     WHERE id = 8;
UPDATE users SET email = 'jaser.mohamed@gmail.com' WHERE id = 9;
UPDATE users SET email = 'omar.mohamed@gmail.com'  WHERE id = 10;
UPDATE users SET email = 'nour.ahmed@gmail.com'    WHERE id = 11;
UPDATE users SET email = 'reem.khaled@gmail.com'   WHERE id = 12;
UPDATE users SET email = 'karim.yousef@gmail.com'  WHERE id = 13;
UPDATE users SET email = 'sara.walid@gmail.com'    WHERE id = 14;
UPDATE users SET email = 'hana.tarek@gmail.com'    WHERE id = 15;
UPDATE users SET email = 'ahmed.maher@gmail.com'   WHERE id = 16;
UPDATE users SET email = 'rana.sameh@gmail.com'    WHERE id = 17;
UPDATE users SET email = 'mostafa.alaa@gmail.com'  WHERE id = 18;

-- أحساب الأطفال (كلهم دفعة واحدة)
SET SQL_SAFE_UPDATES = 0;

-- أحساب الأطفال
UPDATE users 
SET email = REPLACE(email, '@autism.com', '@gmail.com')
WHERE role = 'child';

SET SQL_SAFE_UPDATES = 1;

-- تحقق
SELECT id, full_name, email, role FROM users ORDER BY id;