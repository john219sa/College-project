<?php
// ════════════════════════════════════════════════════════
// htdocs/API/children/get_specialist_children.php
// ════════════════════════════════════════════════════════

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

include("../config/database.php");

$specialist_id = isset($_GET['specialist_id'])
    ? intval($_GET['specialist_id'])
    : 0;

if ($specialist_id <= 0) {
    echo json_encode([
        "status"  => false,
        "message" => "specialist_id مطلوب"
    ]);
    exit;
}

$sql = "
    SELECT
        c.id,
        c.name,
        c.age,
        c.diagnosis,
        c.family_id,
        f.name AS family_name

    FROM specialist_children sc

    JOIN children c
        ON sc.child_id = c.id

    LEFT JOIN families f
        ON c.family_id = f.id

    WHERE sc.specialist_id = $specialist_id

    ORDER BY c.name
";

$result = mysqli_query($conn, $sql);

if (!$result) {
    echo json_encode([
        "status"  => false,
        "message" => "خطأ في قاعدة البيانات: " . mysqli_error($conn)
    ]);
    exit;
}

$list = [];
while ($row = mysqli_fetch_assoc($result)) {
    $list[] = [
        "id"          => (int) $row['id'],
        "name"        => $row['name'],
        "age"         => (int) $row['age'],
        "diagnosis"   => $row['diagnosis'],
        "family_id"   => (int) $row['family_id'],
        "family_name" => $row['family_name'] ?? '',
    ];
}

echo json_encode([
    "status" => true,
    "count"  => count($list),
    "data"   => $list
]);
?>