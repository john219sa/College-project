<?php
// ════════════════════════════════════════════════════════
// htdocs/API/sessions/get_sessions.php
// ════════════════════════════════════════════════════════
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
include("../config/database.php");

$specialist_id = isset($_GET['specialist_id']) ? intval($_GET['specialist_id']) : 0;
$child_id      = isset($_GET['child_id'])      ? intval($_GET['child_id'])      : 0;
$date          = isset($_GET['date'])          ? trim($_GET['date'])            : '';

$where = [];
$join  = "";

if ($specialist_id > 0) {
    $where[] = "s.specialist_id = $specialist_id";
}

if ($child_id > 0) {
    $join    = "JOIN session_children sc ON s.id = sc.session_id";
    $where[] = "sc.child_id = $child_id";
}

if (!empty($date)) {
    $d       = mysqli_real_escape_string($conn, $date);
    $where[] = "s.session_date = '$d'";
}

$where_sql = !empty($where) ? "WHERE " . implode(" AND ", $where) : "";

$sql = "
    SELECT DISTINCT
        s.id,
        s.session_date,
        s.session_time,
        s.location,
        s.session_type,
        s.status,
        s.notes,
        u.full_name     AS specialist_name,
        u.specialist_type
    FROM sessions s
    JOIN users u ON s.specialist_id = u.id
    $join
    $where_sql
    ORDER BY s.session_date DESC, s.session_time ASC
";

$result   = mysqli_query($conn, $sql);
$sessions = [];

while ($row = mysqli_fetch_assoc($result)) {
    $sid = $row['id'];

    // ── الأطفال لكل جلسة ──────────────────────────────────
    $ch_result = mysqli_query($conn, "
        SELECT c.id, c.name, c.age, c.diagnosis
        FROM session_children sc
        JOIN children c ON sc.child_id = c.id
        WHERE sc.session_id = $sid
    ");
    $children = [];
    while ($ch = mysqli_fetch_assoc($ch_result)) {
        $children[] = $ch;
    }
    $row['children'] = $children;
    $sessions[]      = $row;
}

// ── الإحصائيات ─────────────────────────────────────────────
$total   = count($sessions);
$done    = count(array_filter($sessions, fn($s) => $s['status'] === 'done'));
$pending = count(array_filter($sessions, fn($s) => $s['status'] === 'pending'));

echo json_encode([
    "status"  => true,
    "count"   => $total,
    "stats"   => [
        "total"   => $total,
        "done"    => $done,
        "pending" => $pending,
    ],
    "data"    => $sessions,
]);
?>