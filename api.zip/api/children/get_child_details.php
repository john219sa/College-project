<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

require_once "../config/database.php";

$data     = json_decode(file_get_contents("php://input"), true);
$child_id = isset($data['child_id'])
    ? intval($data['child_id'])
    : (isset($_GET['child_id']) ? intval($_GET['child_id']) : 0);

if ($child_id <= 0) {
    echo json_encode(["status" => false, "message" => "child_id required"]);
    exit;
}

$response = ["status" => true];

$tables = [
    "child"      => "SELECT * FROM children WHERE id = $child_id",
    "treatments" => "SELECT * FROM child_treatments WHERE child_id = $child_id ORDER BY id DESC",
    "exercises"  => "SELECT * FROM child_exercises  WHERE child_id = $child_id ORDER BY id DESC",
    "reports"    => "SELECT * FROM child_reports    WHERE child_id = $child_id ORDER BY id DESC",
    "scans"      => "SELECT * FROM child_scans      WHERE child_id = $child_id ORDER BY id DESC",
    "tests"      => "SELECT * FROM child_tests      WHERE child_id = $child_id ORDER BY id DESC",
    "comments"   => "SELECT c.*, u.full_name FROM child_comments c
                     JOIN users u ON c.user_id = u.id
                     WHERE c.child_id = $child_id ORDER BY c.id DESC",
];

foreach ($tables as $key => $query) {
    $result = mysqli_query($conn, $query);
    if ($key === "child") {
        $response[$key] = mysqli_fetch_assoc($result) ?: (object)[];
    } else {
        $rows = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $rows[] = $row;
        }
        $response[$key] = $rows;
    }
}

// ── الجلسات ──────────────────────────────────────────────
$sessions_query = "
    SELECT s.id, s.session_date, s.session_time, s.location,
           s.session_type, s.status, s.notes,
           u.full_name     AS specialist_name,
           u.specialist_type
    FROM sessions s
    JOIN session_children sc ON sc.session_id = s.id
    JOIN users u             ON u.id = s.specialist_id
    WHERE sc.child_id = $child_id
    ORDER BY s.session_date DESC, s.session_time DESC
";
$sessions_result    = mysqli_query($conn, $sessions_query);
$sessions           = [];
while ($row = mysqli_fetch_assoc($sessions_result)) {
    $sessions[] = $row;
}
$response['sessions'] = $sessions;

echo json_encode($response);
?>