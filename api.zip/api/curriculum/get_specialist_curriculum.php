<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
require_once "../config/database.php";

$specialist_id = isset($_GET['specialist_id']) ? intval($_GET['specialist_id']) : 0;
if ($specialist_id <= 0) {
    echo json_encode(["status" => false, "message" => "specialist_id مطلوب"]);
    exit;
}

$sql = "SELECT * FROM curriculum_uploads
        WHERE specialist_id = $specialist_id
        ORDER BY created_at DESC";

$result = mysqli_query($conn, $sql);
$list   = [];
while ($row = mysqli_fetch_assoc($result)) {
    $list[] = $row;
}

echo json_encode(["status" => true, "data" => $list]);
?>