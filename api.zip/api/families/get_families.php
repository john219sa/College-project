<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
require_once "../config/database.php";

$result = mysqli_query($conn, "SELECT id, name FROM families ORDER BY id");
$list = [];
while ($row = mysqli_fetch_assoc($result)) {
    $list[] = $row;
}

echo json_encode(["status" => true, "data" => $list]);
?>