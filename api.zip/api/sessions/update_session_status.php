<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
require_once "../config/database.php";

$data      = json_decode(file_get_contents("php://input"), true);
$id        = intval($data['session_id'] ?? 0);
$allowed   = ['pending', 'done', 'cancelled'];
$newStatus = in_array($data['status'], $allowed) ? $data['status'] : 'pending';

if ($id <= 0) {
    echo json_encode(["status" => false, "message" => "session_id مطلوب"]);
    exit;
}

mysqli_query($conn, "UPDATE sessions SET status = '$newStatus' WHERE id = $id");
echo json_encode(["status" => true, "message" => "تم التحديث"]);
?>