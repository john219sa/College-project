<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
require_once "../config/database.php";

$sql = "SELECT u.id, u.full_name, u.specialist_type, f.name as family_name
        FROM users u
        LEFT JOIN families f ON u.family_id = f.id
        WHERE u.role = 'specialist' AND u.is_active = 1
        ORDER BY u.family_id, u.specialist_type";

$result = mysqli_query($conn, $sql);
$list = [];
while ($row = mysqli_fetch_assoc($result)) {
    $list[] = $row;
}

echo json_encode(["status" => true, "data" => $list]);
?>