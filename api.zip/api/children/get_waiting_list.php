<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
require_once "../config/database.php";

$status = isset($_GET['status']) ? mysqli_real_escape_string($conn, $_GET['status']) : 'pending';
$where  = $status !== 'all' ? "WHERE w.status = '$status'" : "";

$sql = "SELECT w.id, w.name, w.age, w.phone, w.service_type, w.email,
               w.status, w.created_at,
               f.name AS family_name
        FROM waiting_list w
        LEFT JOIN families f ON w.family_id = f.id
        $where
        ORDER BY w.created_at DESC";

$result = mysqli_query($conn, $sql);
$list   = [];
while ($row = mysqli_fetch_assoc($result)) {
    $list[] = $row;
}

echo json_encode(["status" => true, "data" => $list, "count" => count($list)]);
?>