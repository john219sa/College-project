<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
require_once "../config/database.php";

$specialist_id = isset($_GET['specialist_id']) ? intval($_GET['specialist_id']) : 0;

if ($specialist_id <= 0) {
    echo json_encode(["status" => false, "message" => "specialist_id مطلوب"]);
    exit;
}

$sql = "SELECT c.id, c.name, c.age, c.diagnosis
        FROM specialist_children sc
        JOIN children c ON sc.child_id = c.id
        WHERE sc.specialist_id = $specialist_id
        ORDER BY c.name";

$result = mysqli_query($conn, $sql);
$list = [];
while ($row = mysqli_fetch_assoc($result)) {
    $list[] = $row;
}

echo json_encode(["status" => true, "data" => $list, "count" => count($list)]);
?>