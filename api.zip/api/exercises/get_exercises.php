<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

require_once '../config/database.php';

$child_id = $_GET['child_id'] ?? null;

if (!$child_id) {
    echo json_encode(['status' => false, 'message' => 'child_id مطلوب']);
    exit;
}

$stmt = $conn->prepare("
    SELECT ce.id, ce.title, ce.instructions, ce.created_at,
           u.full_name AS created_by_name
    FROM child_exercises ce
    LEFT JOIN users u ON ce.created_by = u.id
    WHERE ce.child_id = ?
    ORDER BY ce.created_at DESC
");
$stmt->bind_param("i", $child_id);
$stmt->execute();
$result = $stmt->get_result();

$exercises = [];
while ($row = $result->fetch_assoc()) {
    $exercises[] = $row;
}

echo json_encode(['status' => true, 'exercises' => $exercises]);

$stmt->close();
$conn->close();
?>
